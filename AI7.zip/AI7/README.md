# AI7

A mobile app where every question goes to the right AI tool automatically:
general questions and writing, math, code, charts, image generation,
and photos of handwritten questions.

```
AI7 app (Expo)  ->  Your server (Node)  ->  Router picks a tool
                                            |- Ask / Math / Code  (Claude)
                                            |- Chart              (Claude, drawn in the app)
                                            |- Image              (image API)
                                            |- Handwriting photo  (Claude vision)
```

**On answer quality:** each tool uses Claude's current flagship model (Sonnet 5) with
a system prompt written to match the standard of a dedicated app for that subject —
e.g. the math tool is told to show its work and double-check arithmetic, the code
tool to diagnose root causes and follow language conventions. It inherits Claude's
general knowledge and reasoning; it is not a bundle of separate specialist AIs. The
`TEXT_TOOLS` prompts in `server/index.js` are the place to raise the bar further for
any one subject.

The server is required. It keeps your API keys secret. Never put keys inside the app.

Folders:
- `server/` the backend you host
- `app/` the phone app (copy into an Expo project, see step 3)
- `store/` logo images sized for the Play Store listing

---

## 1. Get your keys

- `ANTHROPIC_API_KEY`: create one at console.anthropic.com
- `IMAGE_API_KEY` (optional, for image generation): an OpenAI API key. Without it, everything else still works.

## 2. Run the server on your computer

Install Node.js (nodejs.org), then:

```
cd server
npm install express cors dotenv @anthropic-ai/sdk
cp .env.example .env
```

Paste your keys into `.env`, then run `npm start`.
You should see "Server listening on http://localhost:3000".

## 3. Create the app

Outside this folder:

```
npx create-expo-app@latest ai7 --template blank
cd ai7
npx expo install expo-image-picker react-native-svg
```

Copy everything from this project's `app` folder into `ai7`
(replace `App.js` and `app.json`; add `src`, `assets` and `eas.json`).

Open `src/config.js` and set `API_URL` to your computer's local IP,
for example `http://192.168.1.20:3000`. Phone and computer must share the same Wi-Fi.

Run `npx expo start`, install **Expo Go** on your phone, and scan the QR code.

---

## 4. Host the server (you are the host)

For the Play Store the server must be online all the time, at an **https** address.
Android release apps block plain http.

1. Put the `server` folder on GitHub.
2. Deploy it on a host such as Render, Railway or Fly.io (all can run a Node app).
3. Add `ANTHROPIC_API_KEY` and `IMAGE_API_KEY` in the host's environment settings (not in the code).
4. Copy the public https address into `API_URL` in `src/config.js`.

The server limits each IP to 40 questions per hour (`HOURLY_LIMIT` in the environment changes it).
Before a large launch, add user login so limits apply per person.

## 5. Publish on Google Play

**You must do the actual uploading** — Google only lets the app's registered owner
publish it, with their own account, identity verification and signed agreements.
I can prepare every file and walk you through each screen, but I can't sign in or
submit this for you.

**Set your package name first.** In `app.json`, change `com.yourname.ai7` to your own
(for example `com.johnsmith.ai7`). It can never be changed after publishing.

**Build the release file:**

```
npm install -g eas-cli
eas login
eas init
eas build --platform android --profile production
```

This produces an `.aab` file. (Use `--profile preview` for a test `.apk` you can install directly.)

**Google Play Console (play.google.com/console):**

1. Create a developer account (one-time fee, identity verification required).
2. Create the app, then upload the `.aab`.
3. Store listing: use `store/play-store-icon-512.png` as the icon and `store/feature-graphic-1024x500.png` as the feature graphic. Add at least 2 phone screenshots, a short description and a full description.
4. Fill in: privacy policy URL, Data safety form, content rating, and target audience.
5. If your developer account is a **personal account created after 13 Nov 2023**, Google requires a closed test with at least 12 testers opted in for 14 continuous days before you can apply for production access. Organization accounts are exempt. Check Google's current rules in Play Console Help.

**Things Google will expect for this app:**

- A privacy policy that says photos and questions are sent to a server and to AI providers.
- Because AI7 generates content, an in-app way to report offensive or harmful answers (Google's AI-generated content policy). This is not built yet.

## Adding a new tool later

In `server/index.js`, add an entry to `TEXT_TOOLS` (or a new handler) and one line to the router prompt in `route()`.
Then add a label and color in `app/src/theme.js`.
