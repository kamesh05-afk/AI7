import { API_URL } from "./config";

export async function ask({ message, image, history }) {
  let res;
  try {
    res = await fetch(`${API_URL}/ask`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message,
        imageBase64: image?.base64,
        mediaType: image?.mediaType,
        history,
      }),
    });
  } catch {
    throw new Error(
      "Can't reach the server. Check that it's running and that API_URL in src/config.js is correct."
    );
  }

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Server error (${res.status}). Please try again.`);
  }
  return res.json();
}
