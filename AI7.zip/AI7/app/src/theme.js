// The app name shown in the header.
export const APP_NAME = "AI7";

export const colors = {
  paper: "#F6F7F9",
  card: "#FFFFFF",
  ink: "#14213D",
  muted: "#6B7385",
  line: "#E2E5EC",
  danger: "#C92A2A",
};

// Each tool gets its own color so users can see who answered.
export const tools = {
  general: { label: "Ask", color: "#3B6FE0" },
  math: { label: "Math", color: "#0E9F8E" },
  code: { label: "Code", color: "#6D4AFF" },
  chart: { label: "Chart", color: "#E58A00" },
  image: { label: "Image", color: "#D6336C" },
};
