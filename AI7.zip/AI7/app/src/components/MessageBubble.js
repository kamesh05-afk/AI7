import React from "react";
import { View, Text, Image, StyleSheet, useWindowDimensions, Platform } from "react-native";
import ChartView from "./ChartView";
import { colors, tools } from "../theme";

const MONO = Platform.OS === "ios" ? "Menlo" : "monospace";

// Splits text into normal parts and ```code``` parts.
function splitCode(text) {
  const parts = [];
  const re = /```(?:[\w+-]*)\n?([\s\S]*?)```/g;
  let last = 0;
  let m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) parts.push({ code: false, value: text.slice(last, m.index).trim() });
    parts.push({ code: true, value: m[1].replace(/\n$/, "") });
    last = re.lastIndex;
  }
  if (last < text.length) parts.push({ code: false, value: text.slice(last).trim() });
  return parts.filter((p) => p.value);
}

export default function MessageBubble({ message }) {
  const { width } = useWindowDimensions();
  const bubbleWidth = width * 0.86;

  if (message.role === "user") {
    return (
      <View style={[styles.row, { justifyContent: "flex-end" }]}>
        <View style={[styles.bubble, styles.userBubble]}>
          {!!message.imageUri && <Image source={{ uri: message.imageUri }} style={styles.userPhoto} />}
          {!!message.text && <Text style={styles.userText}>{message.text}</Text>}
        </View>
      </View>
    );
  }

  const tool = tools[message.tool];
  const isError = message.kind === "error";

  return (
    <View style={styles.row}>
      <View style={[styles.bubble, styles.aiBubble, { maxWidth: bubbleWidth }]}>
        {tool && (
          <View style={styles.badgeRow}>
            <View style={[styles.dot, { backgroundColor: tool.color }]} />
            <Text style={[styles.badgeText, { color: tool.color }]}>{tool.label}</Text>
          </View>
        )}

        {!!message.transcript && (
          <Text style={styles.transcript}>Read from your photo: {message.transcript}</Text>
        )}

        {message.kind === "chart" && message.chart && (
          <ChartView chart={message.chart} width={bubbleWidth - 28} />
        )}

        {message.kind === "image" && !!message.imageUri && (
          <Image
            source={{ uri: message.imageUri }}
            style={{ width: bubbleWidth - 28, height: bubbleWidth - 28, borderRadius: 10 }}
          />
        )}

        {!!message.text &&
          splitCode(message.text).map((part, i) =>
            part.code ? (
              <View key={i} style={styles.codeBox}>
                <Text selectable style={styles.codeText}>
                  {part.value}
                </Text>
              </View>
            ) : (
              <Text key={i} selectable style={[styles.aiText, isError && { color: colors.danger }]}>
                {part.value}
              </Text>
            )
          )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: "row", marginVertical: 6, paddingHorizontal: 12 },
  bubble: { borderRadius: 16, padding: 12 },
  userBubble: { backgroundColor: colors.ink, maxWidth: "80%" },
  userText: { color: "#fff", fontSize: 16, lineHeight: 22 },
  userPhoto: { width: 180, height: 180, borderRadius: 10, marginBottom: 6 },
  aiBubble: { backgroundColor: colors.card, borderWidth: 1, borderColor: colors.line },
  aiText: { color: colors.ink, fontSize: 16, lineHeight: 23, marginTop: 4 },
  badgeRow: { flexDirection: "row", alignItems: "center", marginBottom: 4 },
  dot: { width: 8, height: 8, borderRadius: 4, marginRight: 6 },
  badgeText: { fontSize: 13, fontWeight: "600" },
  transcript: { color: colors.muted, fontSize: 13, fontStyle: "italic", marginBottom: 6 },
  codeBox: { backgroundColor: "#0F1B33", borderRadius: 10, padding: 10, marginVertical: 6 },
  codeText: { color: "#E6EDF7", fontFamily: MONO, fontSize: 13, lineHeight: 19 },
});
