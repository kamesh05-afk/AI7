import React from "react";
import { View, Text, StyleSheet } from "react-native";
import Svg, { Rect, Polyline, Line, Circle, Text as SvgText } from "react-native-svg";
import { colors, tools } from "../theme";

const HEIGHT = 210;
const PAD = { l: 40, r: 12, t: 12, b: 28 };

const fmt = (v) => (Number.isInteger(v) ? String(v) : v.toFixed(2));

export default function ChartView({ chart, width }) {
  const { title, type, labels, values } = chart;
  const color = tools.chart.color;

  const innerW = width - PAD.l - PAD.r;
  const innerH = HEIGHT - PAD.t - PAD.b;
  const max = Math.max(...values, 0);
  const min = Math.min(...values, 0);
  const span = max - min || 1;
  const n = values.length;

  const y = (v) => PAD.t + innerH - ((v - min) / span) * innerH;
  const zeroY = y(0);
  const slot = innerW / n;
  const xBar = (i) => PAD.l + i * slot + slot * 0.15;
  const xLine = (i) => (n === 1 ? PAD.l + innerW / 2 : PAD.l + (i / (n - 1)) * innerW);
  const labelStep = Math.ceil(n / 6);

  return (
    <View>
      {!!title && <Text style={styles.title}>{title}</Text>}
      <Svg width={width} height={HEIGHT}>
        <Line x1={PAD.l} y1={zeroY} x2={width - PAD.r} y2={zeroY} stroke={colors.line} strokeWidth={1} />
        <Line x1={PAD.l} y1={PAD.t} x2={PAD.l} y2={PAD.t + innerH} stroke={colors.line} strokeWidth={1} />
        <SvgText x={PAD.l - 6} y={PAD.t + 4} fontSize={10} fill={colors.muted} textAnchor="end">
          {fmt(max)}
        </SvgText>
        <SvgText x={PAD.l - 6} y={PAD.t + innerH} fontSize={10} fill={colors.muted} textAnchor="end">
          {fmt(min)}
        </SvgText>

        {type === "bar" &&
          values.map((v, i) => (
            <Rect
              key={i}
              x={xBar(i)}
              y={Math.min(y(v), zeroY)}
              width={slot * 0.7}
              height={Math.max(Math.abs(y(v) - zeroY), 1)}
              rx={3}
              fill={color}
            />
          ))}

        {type === "line" && (
          <>
            <Polyline
              points={values.map((v, i) => `${xLine(i)},${y(v)}`).join(" ")}
              fill="none"
              stroke={color}
              strokeWidth={2.5}
            />
            {values.map((v, i) => (
              <Circle key={i} cx={xLine(i)} cy={y(v)} r={n > 20 ? 0 : 3} fill={color} />
            ))}
          </>
        )}

        {labels.map((label, i) =>
          i % labelStep === 0 ? (
            <SvgText
              key={i}
              x={type === "bar" ? xBar(i) + (slot * 0.7) / 2 : xLine(i)}
              y={HEIGHT - 8}
              fontSize={10}
              fill={colors.muted}
              textAnchor="middle"
            >
              {label.length > 8 ? label.slice(0, 7) + "…" : label}
            </SvgText>
          ) : null
        )}
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  title: { fontSize: 15, fontWeight: "600", color: colors.ink, marginBottom: 6 },
});
