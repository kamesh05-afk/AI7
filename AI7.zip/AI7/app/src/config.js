// Where your server is running.
// While testing on your phone, use your computer's local IP address,
// for example "http://192.168.1.20:3000" (not "localhost").
// After you deploy the server, replace this with its public https address.
export const API_URL = "http://YOUR-COMPUTER-IP:3000";
