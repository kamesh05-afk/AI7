import React, { useRef, useState } from "react";
import {
  View,
  Text,
  TextInput,
  FlatList,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Image,
  Alert,
  StatusBar,
  SafeAreaView,
  StyleSheet,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import { ask } from "./src/api";
import MessageBubble from "./src/components/MessageBubble";
import { colors, tools, APP_NAME } from "./src/theme";

const SUGGESTIONS = [
  { text: "Solve 3x + 7 = 25", tool: "math" },
  { text: "Plot y = x^2 from -5 to 5", tool: "chart" },
  { text: "Write a Python function to reverse a string", tool: "code" },
  { text: "Draw a lighthouse at sunrise, watercolor style", tool: "image" },
  { text: "Write a polite email asking for a deadline extension", tool: "general" },
];

export default function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [image, setImage] = useState(null); // photo waiting to be sent
  const [loading, setLoading] = useState(false);
  const listRef = useRef(null);

  const launch = async (source) => {
    try {
      let result;
      if (source === "camera") {
        const perm = await ImagePicker.requestCameraPermissionsAsync();
        if (!perm.granted) {
          Alert.alert("Camera access needed", "Allow camera access in Settings to photograph a question.");
          return;
        }
        result = await ImagePicker.launchCameraAsync({ base64: true, quality: 0.5 });
      } else {
        result = await ImagePicker.launchImageLibraryAsync({
          base64: true,
          quality: 0.5,
          mediaTypes: ["images"],
        });
      }
      if (result.canceled) return;
      const a = result.assets[0];
      setImage({ uri: a.uri, base64: a.base64, mediaType: a.mimeType || "image/jpeg" });
    } catch {
      Alert.alert("Couldn't add the photo", "Please try again.");
    }
  };

  const pickImage = () =>
    Alert.alert("Add a photo", "Photograph a handwritten question", [
      { text: "Take photo", onPress: () => launch("camera") },
      { text: "Choose from library", onPress: () => launch("library") },
      { text: "Cancel", style: "cancel" },
    ]);

  const send = async (override) => {
    const text = (typeof override === "string" ? override : input).trim();
    if ((!text && !image) || loading) return;

    const history = messages
      .filter((m) => m.text)
      .map((m) => ({ role: m.role, text: m.text }));
    const sentImage = image;

    setMessages((prev) => [
      ...prev,
      { id: `u${Date.now()}`, role: "user", text, imageUri: sentImage?.uri },
    ]);
    setInput("");
    setImage(null);
    setLoading(true);

    try {
      const reply = await ask({ message: text, image: sentImage, history });
      setMessages((prev) => [...prev, { id: `a${Date.now()}`, role: "assistant", ...reply }]);
    } catch (e) {
      setMessages((prev) => [
        ...prev,
        { id: `e${Date.now()}`, role: "assistant", kind: "error", text: e.message },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const empty = (
    <View style={styles.empty}>
      <Text style={styles.emptyTitle}>Ask anything</Text>
      <Text style={styles.emptyBody}>
        Type a question or photograph a handwritten one. The right tool answers automatically.
      </Text>
      {SUGGESTIONS.map((s) => (
        <TouchableOpacity key={s.text} style={styles.chip} onPress={() => send(s.text)}>
          <View style={[styles.chipDot, { backgroundColor: tools[s.tool].color }]} />
          <Text style={styles.chipText}>{s.text}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" />
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{APP_NAME}</Text>
      </View>

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={(m) => m.id}
          renderItem={({ item }) => <MessageBubble message={item} />}
          ListEmptyComponent={empty}
          contentContainerStyle={{ paddingVertical: 8, flexGrow: 1 }}
          onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: true })}
          keyboardShouldPersistTaps="handled"
        />

        {loading && (
          <View style={styles.thinking}>
            <ActivityIndicator size="small" color={colors.muted} />
            <Text style={styles.thinkingText}>Finding the right tool…</Text>
          </View>
        )}

        {image && (
          <View style={styles.preview}>
            <Image source={{ uri: image.uri }} style={styles.previewImg} />
            <TouchableOpacity onPress={() => setImage(null)}>
              <Text style={styles.remove}>Remove photo</Text>
            </TouchableOpacity>
          </View>
        )}

        <View style={styles.inputBar}>
          <TouchableOpacity style={styles.photoBtn} onPress={pickImage} accessibilityLabel="Add photo">
            <Text style={styles.photoBtnText}>Photo</Text>
          </TouchableOpacity>
          <TextInput
            style={styles.input}
            value={input}
            onChangeText={setInput}
            placeholder="Ask a question"
            placeholderTextColor={colors.muted}
            multiline
          />
          <TouchableOpacity
            style={[styles.sendBtn, loading && { opacity: 0.5 }]}
            onPress={() => send()}
            disabled={loading}
            accessibilityLabel="Send"
          >
            <Text style={styles.sendText}>Send</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.paper, paddingTop: Platform.OS === "android" ? StatusBar.currentHeight : 0 },
  header: { paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: colors.line },
  headerTitle: { fontSize: 20, fontWeight: "700", color: colors.ink },
  empty: { padding: 20, paddingTop: 32 },
  emptyTitle: { fontSize: 26, fontWeight: "700", color: colors.ink },
  emptyBody: { fontSize: 15, lineHeight: 22, color: colors.muted, marginTop: 6, marginBottom: 20 },
  chip: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 12,
    padding: 14,
    marginBottom: 10,
  },
  chipDot: { width: 10, height: 10, borderRadius: 5, marginRight: 10 },
  chipText: { flex: 1, fontSize: 15, color: colors.ink },
  thinking: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingBottom: 6 },
  thinkingText: { marginLeft: 8, color: colors.muted, fontSize: 14 },
  preview: { flexDirection: "row", alignItems: "center", paddingHorizontal: 12, paddingBottom: 6 },
  previewImg: { width: 56, height: 56, borderRadius: 8, marginRight: 12 },
  remove: { color: colors.danger, fontSize: 14 },
  inputBar: {
    flexDirection: "row",
    alignItems: "flex-end",
    padding: 10,
    borderTopWidth: 1,
    borderTopColor: colors.line,
    backgroundColor: colors.card,
  },
  photoBtn: { paddingHorizontal: 12, paddingVertical: 10, marginRight: 6 },
  photoBtnText: { color: colors.ink, fontWeight: "600", fontSize: 15 },
  input: {
    flex: 1,
    maxHeight: 120,
    backgroundColor: colors.paper,
    borderRadius: 18,
    paddingHorizontal: 14,
    paddingTop: 10,
    paddingBottom: 10,
    fontSize: 16,
    color: colors.ink,
  },
  sendBtn: { backgroundColor: colors.ink, borderRadius: 18, paddingHorizontal: 16, paddingVertical: 11, marginLeft: 8 },
  sendText: { color: "#fff", fontWeight: "600", fontSize: 15 },
});
