import "dotenv/config";
import express from "express";
import cors from "cors";
import Anthropic from "@anthropic-ai/sdk";

const app = express();
app.use(cors());
app.use(express.json({ limit: "15mb" })); // photos arrive as base64

app.set("trust proxy", 1); // needed when hosted behind a proxy (Render, Railway, etc.)

// Basic protection: limit each IP address to a number of questions per hour.
// This is a stopgap. Add user accounts for stronger, per-user limits.
const HOURLY_LIMIT = Number(process.env.HOURLY_LIMIT || 40);
const WINDOW_MS = 60 * 60 * 1000;
const hits = new Map(); // ip -> array of timestamps

function rateLimit(req, res, next) {
  const now = Date.now();
  const recent = (hits.get(req.ip) || []).filter((t) => now - t < WINDOW_MS);
  if (recent.length >= HOURLY_LIMIT) {
    return res.status(429).json({ error: "You've reached the hourly limit. Please try again later." });
  }
  recent.push(now);
  hits.set(req.ip, recent);
  next();
}
setInterval(() => {
  const now = Date.now();
  for (const [ip, times] of hits) {
    if (!times.some((t) => now - t < WINDOW_MS)) hits.delete(ip);
  }
}, WINDOW_MS).unref();

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const FAST_MODEL = "claude-haiku-4-5-20251001"; // used for routing (cheap and quick)
const SMART_MODEL = "claude-sonnet-5"; // used for answers - Anthropic's current general-purpose model

// ---------------------------------------------------------------
// The tools. Add a new tool by adding an entry here and a line in
// the router prompt below.
// ---------------------------------------------------------------
const TEXT_TOOLS = {
  general:
    "You are a knowledgeable, precise assistant for general questions and writing, " +
    "held to the same bar as a dedicated writing or research assistant app. " +
    "Answer directly and accurately; if you are not confident of a fact, say so " +
    "rather than guessing. Match the depth of the question: a quick fact gets a " +
    "short answer, a request for an essay or plan gets full, well-organised content. " +
    "Use plain text, no markdown headers.",
  math:
    "You are a rigorous math and problem-solving tutor, held to the same bar as a " +
    "dedicated math-solver app. Work step by step, show the reasoning (not just the " +
    "result), double-check your arithmetic and algebra before answering, and finish " +
    "with a line starting with 'Answer:'. If the problem is ambiguous, state the " +
    "assumption you're making. Write math in plain text (for example x^2, sqrt(x), " +
    "3/4), not LaTeX.",
  code:
    "You are an expert software engineer, held to the same bar as a dedicated coding " +
    "assistant. Give correct, working code inside triple-backtick fenced blocks with " +
    "the language name, following that language's conventions and current best " +
    "practices. For a bug, diagnose the root cause before giving the fix. For a " +
    "feature, briefly note edge cases or trade-offs worth knowing. Keep the " +
    "explanation after the code short and concrete.",
};

const CHART_PROMPT =
  "You turn a request into a chart. Reply with ONLY a JSON object, no other text, in this shape:\n" +
  '{"title": string, "type": "bar" | "line", "labels": string[], "values": number[], "explanation": string}\n' +
  "Rules: labels and values must have the same length (max 20). " +
  "For a function like y = x^2, use type line and sample about 15 evenly spaced x values. " +
  "For comparisons or categories, use type bar. Keep explanation to 1-3 sentences.";

// ---------------------------------------------------------------
// Step 1: decide which tool should answer.
// ---------------------------------------------------------------
async function route(question) {
  const res = await client.messages.create({
    model: FAST_MODEL,
    max_tokens: 10,
    system:
      "Classify the user's request. Reply with exactly one word:\n" +
      "math - calculations, equations, word problems, science problems\n" +
      "code - programming, debugging, technical how-to for software\n" +
      "chart - asks to graph, plot, chart, or visualise data or a function\n" +
      "image - asks to create, draw, or generate a picture or artwork\n" +
      "general - everything else (facts, advice, writing, explanations)",
    messages: [{ role: "user", content: question }],
  });
  const block = res.content.find((b) => b.type === "text");
  const word = block?.text.trim().toLowerCase() ?? "general";
  return ["math", "code", "chart", "image", "general"].includes(word) ? word : "general";
}

// ---------------------------------------------------------------
// Handwriting: read a photo of a handwritten question.
// ---------------------------------------------------------------
async function readHandwriting(imageBase64, mediaType) {
  const res = await client.messages.create({
    model: SMART_MODEL,
    max_tokens: 800,
    system:
      "Transcribe the handwritten question in the image exactly as written. " +
      "Write math in plain text. Output only the transcription. " +
      "If nothing readable is present, output exactly: UNREADABLE",
    messages: [
      {
        role: "user",
        content: [
          { type: "image", source: { type: "base64", media_type: mediaType, data: imageBase64 } },
          { type: "text", text: "Transcribe the question." },
        ],
      },
    ],
  });
  const block = res.content.find((b) => b.type === "text");
  return block?.text.trim() ?? "UNREADABLE";
}

// ---------------------------------------------------------------
// Tool handlers
// ---------------------------------------------------------------
function cleanHistory(history) {
  const items = (Array.isArray(history) ? history : [])
    .slice(-6)
    .filter((h) => (h.role === "user" || h.role === "assistant") && h.text?.trim())
    .map((h) => ({ role: h.role, content: h.text }));
  while (items.length && items[0].role !== "user") items.shift(); // must start with user
  return items;
}

async function answerText(tool, question, history) {
  const res = await client.messages.create({
    model: SMART_MODEL,
    max_tokens: 1500,
    system: TEXT_TOOLS[tool],
    messages: [...cleanHistory(history), { role: "user", content: question }],
  });
  const text = res.content
    .filter((b) => b.type === "text")
    .map((b) => b.text)
    .join("\n");
  return { tool, kind: "text", text };
}

async function answerChart(question) {
  const res = await client.messages.create({
    model: SMART_MODEL,
    max_tokens: 1200,
    system: CHART_PROMPT,
    messages: [{ role: "user", content: question }],
  });
  const raw = res.content.find((b) => b.type === "text")?.text ?? "";
  try {
    const json = JSON.parse(raw.replace(/```json|```/g, "").trim());
    const ok =
      Array.isArray(json.labels) &&
      Array.isArray(json.values) &&
      json.labels.length === json.values.length &&
      json.values.length > 0 &&
      json.values.every((v) => typeof v === "number" && Number.isFinite(v));
    if (!ok) throw new Error("bad chart");
    return {
      tool: "chart",
      kind: "chart",
      text: json.explanation ?? "",
      chart: {
        title: json.title ?? "",
        type: json.type === "line" ? "line" : "bar",
        labels: json.labels.map(String),
        values: json.values,
      },
    };
  } catch {
    return answerText("general", question, []); // fall back to a normal answer
  }
}

// Claude does not generate images, so this uses a separate image API.
// The default below is OpenAI's Images API; swap in any provider you like.
async function answerImage(question) {
  if (!process.env.IMAGE_API_KEY) {
    return {
      tool: "image",
      kind: "text",
      text: "Image generation isn't set up yet. Add IMAGE_API_KEY to the server's .env file.",
    };
  }
  const r = await fetch("https://api.openai.com/v1/images/generations", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.IMAGE_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ model: "gpt-image-1", prompt: question, size: "1024x1024" }),
  });
  if (!r.ok) throw new Error(`Image provider error ${r.status}`);
  const data = await r.json();
  const b64 = data.data?.[0]?.b64_json;
  if (!b64) throw new Error("Image provider returned no image");
  return { tool: "image", kind: "image", text: "", imageUri: `data:image/png;base64,${b64}` };
}

// ---------------------------------------------------------------
// The one endpoint the app calls
// ---------------------------------------------------------------
app.post("/ask", rateLimit, async (req, res) => {
  try {
    const { message = "", imageBase64, mediaType = "image/jpeg", history = [] } = req.body;
    let question = String(message).trim().slice(0, 4000);
    let transcript;

    if (imageBase64) {
      transcript = await readHandwriting(imageBase64, mediaType);
      if (transcript.startsWith("UNREADABLE")) {
        return res.json({
          tool: "general",
          kind: "text",
          text: "I couldn't read that photo. Try again in bright light with the page filling the frame.",
        });
      }
      question = question ? `${question}\n\n${transcript}` : transcript;
    }

    if (!question) return res.status(400).json({ error: "Type a question or add a photo." });

    const tool = await route(question);
    let result;
    if (tool === "chart") result = await answerChart(question);
    else if (tool === "image") result = await answerImage(question);
    else result = await answerText(tool, question, history);

    if (transcript) result.transcript = transcript;
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Something went wrong on the server. Please try again." });
  }
});

app.get("/", (_req, res) => res.send("AI7 server is running."));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Server listening on http://localhost:${port}`));
